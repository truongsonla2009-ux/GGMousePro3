package com.example.ggmousepro3ui

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val purple = Color.rgb(155, 75, 255)
    private val dark = Color.rgb(19, 14, 32)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 22)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "GG MOUSE PRO 3"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 58))

        val subtitle = TextView(this).apply {
            text = "GAMING CONTROL PANEL  •  UI DEMO"
            textSize = 11f
            setTextColor(purple)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 30))

        addSection(root, "PERFORMANCE")
        addToggle(root, "Chế độ hiệu năng", "Chỉ là công tắc giao diện")
        addToggle(root, "Giảm hiệu ứng giao diện", "Không thay đổi thiết lập game")

        addSection(root, "ĐỘ NHẠY THAM KHẢO")
        addSlider(root, "Tổng quan", 0, 200, 100)
        addSlider(root, "Red Dot", 0, 200, 95)
        addSlider(root, "Ống ngắm 2X", 0, 200, 90)
        addSlider(root, "Ống ngắm 4X", 0, 200, 85)

        val note = TextView(this).apply {
            text = "Lưu ý: Ứng dụng demo giao diện. Không can thiệp Free Fire, không tự động kéo tâm và không thay đổi độ nhạy trong game."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 22, 0, 10)
        }
        root.addView(note)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun addSection(root: LinearLayout, text: String) {
        val label = TextView(this).apply {
            this.text = text
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(purple)
            setPadding(0, 24, 0, 10)
        }
        root.addView(label)
    }

    private fun addToggle(root: LinearLayout, name: String, detail: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.rgb(37, 27, 55))
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val label = TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(Color.WHITE)
        }
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Switch(this).apply { isChecked = false; buttonTintList = android.content.res.ColorStateList.valueOf(purple) })
        box.addView(row)
        box.addView(TextView(this).apply {
            text = detail
            textSize = 11f
            setTextColor(Color.LTGRAY)
        })
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 10
        root.addView(box, lp)
    }

    private fun addSlider(root: LinearLayout, name: String, min: Int, max: Int, initial: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 8, 16, 8)
            setBackgroundColor(Color.rgb(37, 27, 55))
        }
        val label = TextView(this).apply {
            text = "$name  •  $initial"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = initial - min
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    label.text = "$name  •  ${progress + min}"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        box.addView(label)
        box.addView(seek)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 9
        root.addView(box, lp)
    }
}
